# LaTeX3-doc-cn
翻译一些一些关于 LaTeX3 的材料

## `expl3-doc-cn`
这份文档是英文文档 [expl3.pdf](http://mirrors.ctan.org/macros/latex/contrib/l3kernel/expl3.pdf) 的中文翻译。
该手册简要介绍了 LaTeX3 语法，是学习 LaTeX3 语法以及更多进阶材料的必读文档。

## `xparse-doc-cn`
本文档是 [xparse](http://mirrors.ctan.org/macros/latex/contrib/l3packages/xparse.pdf) 宏包文档的中文翻译。
该宏包提供了 LaTeX3 编程中定义文档命令和环境的方法。

# 许可协议
以上各项目以及源代码以 LPPL 协议发布（[LaTeX Project Public License](http://www.latex-project.org/lppl/)，v1.3c）
