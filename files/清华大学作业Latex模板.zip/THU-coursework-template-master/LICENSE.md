This project is licensed by The LaTeX Project Public Li­cense.

