September 26, 2017 [Xiangxiang]
v1.1
- Add mathcal and eucal package
- Add aligned equations

October 9, 2017 [Xiangxiang]
v1.2
- Add example for figures
- Add example for input matlab codes
- No need to set counter style manually

October 12, 2017 [Xiangxiang]
v1.3
- Add example for vector and random vectors (underline)

October 30, 2017 [Xiangxiang]
v1.4
- Add an example of hypothesis testing

March 22, 2018 [zhaofeng-shu33]
v2.0
- Make it a latex package(.sty)

v2.1
- Use kvoptions to set the coursework counter.

27/03/2018 [zhaofeng-shu33]
v2.2
- Use fancyhdr to set the coursework user file header.

30/03/2018 [zhaofeng-shu33]
v2.3
- User configuration of Homework
- Add solution environment
- User configuration of solution environment name
- Add sample file `ithw.tex`
